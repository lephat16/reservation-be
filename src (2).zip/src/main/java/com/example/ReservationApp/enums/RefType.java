package com.example.ReservationApp.enums;

public enum RefType {
    PO,
    SO,
    ADJ
}
