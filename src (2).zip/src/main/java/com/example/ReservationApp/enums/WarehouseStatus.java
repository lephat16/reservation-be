package com.example.ReservationApp.enums;

public enum WarehouseStatus {
    ACTIVE, INACTIVE
}
