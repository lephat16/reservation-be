package com.example.ReservationApp.enums;

public enum StockChangeType {
    IN,
    OUT,
    ADJ
}
