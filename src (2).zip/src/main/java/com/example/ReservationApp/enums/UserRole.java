package com.example.ReservationApp.enums;

public enum UserRole {
    ADMIN, STAFF, WAREHOUSE
}
