package com.example.ReservationApp.enums;

public enum OrderStatus {
    NEW,
    PROCESSING,
    COMPLETED,
    CANCELLED,
    PENDING
}
