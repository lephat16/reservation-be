package com.example.ReservationApp.enums;

public enum ProductStatus {
    ACTIVE,
    INACTIVE,
    OUT_OF_STOCK
}
