package com.example.ReservationApp.service.product;

import java.util.List;

import com.example.ReservationApp.dto.ResponseDTO;
import com.example.ReservationApp.dto.product.CategoryDTO;

public interface CategoryService {
    
    ResponseDTO<CategoryDTO> createCategory(CategoryDTO categoryDTO);

    ResponseDTO<List<CategoryDTO>> getAllCategories();

    ResponseDTO<CategoryDTO> getCategoryById(Long id);

    ResponseDTO<CategoryDTO> getCategoryByName(String name);

    ResponseDTO<CategoryDTO> updateCategory(Long id, CategoryDTO categoryDTO);

    ResponseDTO<Void> deleteCategory(Long id);

    ResponseDTO<List<CategoryDTO>> getActiveCategories();
}
