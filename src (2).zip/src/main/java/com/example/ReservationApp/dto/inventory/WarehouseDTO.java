package com.example.ReservationApp.dto.inventory;

import java.time.LocalDateTime;
import java.util.List;

import com.example.ReservationApp.enums.WarehouseStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WarehouseDTO {
    private Long id;
    private String name;
    private String location;
    private WarehouseStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;


    private List<InventoryStockDTO> stocks;
}
