package com.example.ReservationApp.dto.inventory;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class InventoryStockDTO {
    private Long id;
    private Long productId;
    private String productName;
    private String warehouseName;
    private Integer quantity;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Integer reservedQuantity ;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<StockHistoryDTO> stockHistories;
}
