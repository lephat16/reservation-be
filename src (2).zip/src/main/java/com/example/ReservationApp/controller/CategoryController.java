package com.example.ReservationApp.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.ReservationApp.dto.ResponseDTO;
import com.example.ReservationApp.dto.product.CategoryDTO;
import com.example.ReservationApp.service.product.CategoryService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/categories")
@RequiredArgsConstructor
public class CategoryController {
    
    private final CategoryService categoryService;

    @PostMapping("/add")
    public ResponseEntity<ResponseDTO<CategoryDTO>> createCategory(@RequestBody @Valid CategoryDTO categoryDTO) {

        return ResponseEntity.ok(categoryService.createCategory(categoryDTO));
    }

    @GetMapping("/all")
    public ResponseEntity<ResponseDTO<List<CategoryDTO>>> getAllCategories() {

        return ResponseEntity.ok(categoryService.getAllCategories());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ResponseDTO<CategoryDTO>> getCategoryById(@PathVariable Long id) {

        return ResponseEntity.ok(categoryService.getCategoryById(id));
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<ResponseDTO<CategoryDTO>> updateCategory(@PathVariable Long id, @RequestBody @Valid CategoryDTO categoryDTO) {

        return ResponseEntity.ok(categoryService.updateCategory(id, categoryDTO));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<ResponseDTO<Void>> deleteCategory(@PathVariable Long id) {

        return ResponseEntity.ok(categoryService.deleteCategory(id));
    }

    @GetMapping("/active")
    public ResponseEntity<ResponseDTO<List<CategoryDTO>>> getActiveCategories() {

        return ResponseEntity.ok(categoryService.getActiveCategories());
    }

    @GetMapping("/name/{name}")
    public ResponseEntity<ResponseDTO<CategoryDTO>> getCategoryByName(@PathVariable String name) {

        return ResponseEntity.ok(categoryService.getCategoryByName(name));
    }
}
