package com.example.ReservationApp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ReservationApp.entity.supplier.SupplierProduct;
import com.example.ReservationApp.enums.SupplierProductStatus;

public interface SupplierProductRepository extends JpaRepository<SupplierProduct, Long> {

    List<SupplierProduct> findBySupplierId(Long supplierId);

    List<SupplierProduct> findBySupplierIdAndStatus(Long supplierId, SupplierProductStatus status);

    boolean existsBySupplierIdAndSupplierSku(Long supplierId, String sku);

    boolean existsBySupplierIdAndSupplierSkuAndIdNot(Long supplierId, String sku, Long excludeId);
}
