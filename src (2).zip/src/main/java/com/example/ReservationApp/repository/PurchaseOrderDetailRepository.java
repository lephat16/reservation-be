package com.example.ReservationApp.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.ReservationApp.entity.transaction.PurchaseOrder;
import com.example.ReservationApp.entity.transaction.PurchaseOrderDetail;

public interface PurchaseOrderDetailRepository extends JpaRepository<PurchaseOrderDetail, Long> {

    List<PurchaseOrderDetail> findByPurchaseOrder(PurchaseOrder purchaseOrder);

    // List<PurchaseOrderDetail> findByPurchaseOrderIdIn(List<Long>
    // purchaseOrderIds);

    @Query("SELECT d FROM PurchaseOrderDetail d WHERE d.purchaseOrder.id IN :ids")
    List<PurchaseOrderDetail> findByPurchaseOrderIdIn(@Param("ids") List<Long> purchaseOrderIds);

    Optional<PurchaseOrderDetail> findByPurchaseOrderIdAndProductId(Long poId, Long productId);
}
