// package com.example.ReservationApp.repository;

// import java.math.BigDecimal;
// import java.time.LocalDateTime;
// import java.util.List;

// import org.springframework.data.jpa.repository.JpaRepository;
// import org.springframework.data.jpa.repository.Query;
// import org.springframework.data.repository.query.Param;

// import com.example.ReservationApp.entity.Transaction;
// import com.example.ReservationApp.enums.TransactionType;

// public interface TransactionRepository extends JpaRepository<Transaction, Long> {
//         List<Transaction> findByUserId(Long userId);

//         @Query("SELECT COALESCE(SUM (t.totalPrice), 0) FROM Transaction t " +
//                         "WHERE t.transactionType = :type " +
//                         "AND t.createdAt >= :startDate")
//         BigDecimal sumByTypeAndDateAfter(@Param("type") TransactionType type,
//                         @Param("startDate") LocalDateTime startDate);

//         List<Transaction> findTop5ByOrderByCreatedAtDesc();

//         @Query("SELECT COALESCE(SUM(i.totalPrice), 0) " +
//                         "FROM TransactionItem i " +
//                         "WHERE i.transaction.transactionType = :type " +
//                         "AND i.product.category.id = :categoryId")
//         BigDecimal sumByCategoryAndType(@Param("categoryId") Long categoryId,
//                         @Param("type") TransactionType type);
// }
