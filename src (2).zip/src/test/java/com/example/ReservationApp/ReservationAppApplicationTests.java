package com.example.ReservationApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservationAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
