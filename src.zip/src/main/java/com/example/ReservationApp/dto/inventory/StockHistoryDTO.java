package com.example.ReservationApp.dto.inventory;

import java.time.LocalDateTime;

import com.example.ReservationApp.enums.RefType;
import com.example.ReservationApp.enums.StockChangeType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StockHistoryDTO {
    private Long id;
    private Long inventoryStockId;
    private Integer changeQty;
    private StockChangeType type; // IN / OUT / ADJ
    private RefType refType; // PO / SO
    private Long refId;
    private String notes;
    private LocalDateTime createdAt;
}

