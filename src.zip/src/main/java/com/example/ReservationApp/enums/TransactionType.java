package com.example.ReservationApp.enums;

public enum TransactionType {
    PURCHASE, SALE, RETURN_TO_SUPPLIER
}
