package com.example.ReservationApp.enums;

public enum SupplierStatus {
    ACTIVE, INACTIVE
}
