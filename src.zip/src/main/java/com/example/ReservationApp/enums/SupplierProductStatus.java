package com.example.ReservationApp.enums;

public enum SupplierProductStatus {
    ACTIVE,
    INACTIVE,
}
