package com.example.ReservationApp.enums;

public enum CategoryStatus {
    ACTIVE, INACTIVE
}
