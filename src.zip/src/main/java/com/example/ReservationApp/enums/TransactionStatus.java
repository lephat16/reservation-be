package com.example.ReservationApp.enums;

public enum TransactionStatus {
    PENDING, PROCESSING, COMPLETED, CANCELLED
}
