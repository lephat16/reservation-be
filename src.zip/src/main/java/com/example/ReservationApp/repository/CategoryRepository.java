package com.example.ReservationApp.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ReservationApp.entity.product.Category;
import com.example.ReservationApp.enums.CategoryStatus;

public interface CategoryRepository extends JpaRepository<Category, Long> {
    boolean existsByname(String name);
    Optional<Category> findByName(String name);
    List<Category> findByStatus(CategoryStatus status);

}
