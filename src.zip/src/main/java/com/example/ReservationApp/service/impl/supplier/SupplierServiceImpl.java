package com.example.ReservationApp.service.impl.supplier;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.example.ReservationApp.dto.ResponseDTO;
import com.example.ReservationApp.dto.supplier.SupplierDTO;
import com.example.ReservationApp.entity.supplier.Supplier;
import com.example.ReservationApp.exception.NotFoundException;
import com.example.ReservationApp.mapper.SupplierMapper;
import com.example.ReservationApp.exception.AlreadyExistException;
import com.example.ReservationApp.repository.SupplierRepository;
import com.example.ReservationApp.service.supplier.SupplierService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 供給者（Supplier）に関するサービス実装クラス。
 * 主な機能:
 * - 供給者の追加、取得、更新、削除
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class SupplierServiceImpl implements SupplierService {

    private final SupplierRepository supplierRepository;
    private final SupplierMapper supplierMapper;

    /**
     * 新しい供給者を追加する。
     *
     * @param supplierDTO 追加する供給者情報を持つDTO
     * @return 追加された供給者のDTOを含むレスポンス
     * @throws AlreadyExistException 名前または電話番号が既に存在する場合
     */
    @Override
    public ResponseDTO<SupplierDTO> addSupplier(SupplierDTO supplierDTO) {

        if (supplierRepository.existsByName(supplierDTO.getName())) {
            throw new AlreadyExistException("この供給者名は既に存在しています。");
        }

        if (supplierRepository.existsByContactInfo(supplierDTO.getContactInfo())) {
            throw new AlreadyExistException("この電話番号は既に登録されています。");
        }
        Supplier supplier = supplierMapper.toEntity(supplierDTO);
        supplierRepository.save(supplier);
        return ResponseDTO.<SupplierDTO>builder()
                .status(HttpStatus.OK.value())
                .message("新しい供給者の追加に成功しました。")
                .data(supplierMapper.toDTO(supplier))
                .build();
    }

    /**
     * 全ての供給者を取得する。
     *
     * @return 供給者DTOのリストを含むレスポンス
     */
    @Override
    public ResponseDTO<List<SupplierDTO>> getAllSuppliers() {

        List<Supplier> suppliers = supplierRepository.findAllWithProducts();
        List<SupplierDTO> supplierDTOs = supplierMapper.toDTOList(suppliers);
        return ResponseDTO.<List<SupplierDTO>>builder()
                .status(HttpStatus.OK.value())
                .message("全て供給者の取得に成功しました。")
                .data(supplierDTOs)
                .build();
    }

    /**
     * 指定したIDの供給者を取得する。
     *
     * @param id 取得対象の供給者ID
     * @return 指定IDの供給者DTOを含むレスポンス
     * @throws NotFoundException 指定した供給者が存在しない場合
     */
    @Override
    public ResponseDTO<SupplierDTO> getSupplierById(Long id) {

        Supplier supplier = supplierRepository.findSupplierWithProductsAndCategory(id)
                .orElseThrow(() -> new NotFoundException("この供給者は見つかりません。"));
        SupplierDTO supplierDTO = supplierMapper.toDTO(supplier);
        return ResponseDTO.<SupplierDTO>builder()
                .status(HttpStatus.OK.value())
                .message("供給者の取得に成功しました。")
                .data(supplierDTO)
                .build();
    }

    /**
     * 指定したIDの供給者情報を更新する。
     *
     * @param id          更新対象の供給者ID
     * @param supplierDTO 更新情報を持つDTO
     * @return 更新後の供給者DTOを含むレスポンス
     * @throws NotFoundException 指定した供給者が存在しない場合
     */
    @Override
    public ResponseDTO<SupplierDTO> updateSupplier(Long id, SupplierDTO supplierDTO) {

        Supplier existingSupplier = supplierRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("この供給者は存在していません。"));
        if (supplierDTO.getName() != null && !supplierDTO.getName().isBlank()) {
            existingSupplier.setName(supplierDTO.getName());
        }
        if (supplierDTO.getAddress() != null && !supplierDTO.getAddress().isBlank()) {
            existingSupplier.setAddress(supplierDTO.getAddress());
        }
        if (supplierDTO.getContactInfo() != null && !supplierDTO.getContactInfo().isBlank()) {
            existingSupplier.setContactInfo(supplierDTO.getContactInfo());
        }
        if (supplierDTO.getSupplierStatus() != null) {
            existingSupplier.setStatus(supplierDTO.getSupplierStatus());
        }
        System.out.println(existingSupplier);
        Supplier updatedSupplier = supplierRepository.save(existingSupplier);
        return ResponseDTO.<SupplierDTO>builder()
                .status(HttpStatus.OK.value())
                .message("供給者の更新に成功しました。")
                .data(supplierMapper.toDTO(updatedSupplier))
                .build();
    }

    /**
     * 指定したIDの供給者を削除する。
     *
     * @param id 削除対象の供給者ID
     * @return 成功メッセージを含むレスポンス
     * @throws NotFoundException 指定した供給者が存在しない場合
     */
    @Override
    public ResponseDTO<Void> deleteSupplier(Long id) {

        Supplier existingSupplier = supplierRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("この供給者は存在していません。"));
        supplierRepository.delete(existingSupplier);
        return ResponseDTO.<Void>builder()
                .status(HttpStatus.OK.value())
                .message("供給者の削除に成功しました。")
                .build();
    }

}
