package com.example.ReservationApp.service.impl.product;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.example.ReservationApp.dto.ResponseDTO;
import com.example.ReservationApp.dto.product.ProductDTO;
import com.example.ReservationApp.entity.product.Category;
import com.example.ReservationApp.entity.product.Product;
import com.example.ReservationApp.exception.NotFoundException;
import com.example.ReservationApp.mapper.ProductMapper;
import com.example.ReservationApp.repository.CategoryRepository;
import com.example.ReservationApp.repository.ProductRepository;
import com.example.ReservationApp.service.product.ProductService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 商品（Product）に関するサービス実装クラス。
 * 主な機能:
 * - 商品の追加、取得、更新、削除
 * - カテゴリごとの商品取得
 * - 商品検索
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class ProductServiceImpl implements ProductService {
    private final ProductRepository productRepository;
    private final ProductMapper productMapper;
    private final CategoryRepository categoryRepository;

    /**
     * 新しい商品を作成する。
     * カテゴリ名が指定されている場合、存在するカテゴリに紐付ける。
     *
     * @param productDTO 作成する商品の情報を持つDTO
     * @return 作成された商品のDTOを含むレスポンス
     * @throws NotFoundException 指定したカテゴリが存在しない場合
     */
    @Override
    public ResponseDTO<ProductDTO> createProduct(ProductDTO productDTO) {
        Product createdProduct = productMapper.toEntity(productDTO);
        if (productDTO.getCategoryName() != null && !productDTO.getCategoryName().isBlank()) {
            Category existingCategory = categoryRepository.findByName(productDTO.getCategoryName())
                    .orElseThrow(() -> new NotFoundException("この製品はどのカテゴリにも属していません。"));
            createdProduct.setCategory(existingCategory);
        }

        Product savedProduct = productRepository.save(createdProduct);

        return ResponseDTO.<ProductDTO>builder()
                .status(HttpStatus.OK.value())
                .message("新しい商品の追加に成功しました。")
                .data(productMapper.toDTO(savedProduct))
                .build();
    }

    /**
     * 全ての商品を取得する。
     *
     * @return 商品DTOのリストを含むレスポンス
     */
    @Override
    public ResponseDTO<List<ProductDTO>> getAllProducts() {

        List<Product> products = productRepository.findAll();
        List<ProductDTO> productDTOs = productMapper.toDTOList(products);

        return ResponseDTO.<List<ProductDTO>>builder()
                .status(HttpStatus.OK.value())
                .message("全て商品の取得に成功しました。")
                .data(productDTOs)
                .build();
    }

    /**
     * 指定IDの商品を取得する。
     *
     * @param id 取得対象の商品ID
     * @return 指定IDの商品DTOを含むレスポンス
     * @throws NotFoundException 指定した商品が存在しない場合
     */
    @Override
    public ResponseDTO<ProductDTO> getProductById(Long id) {

        Product product = productRepository.findById(id)
                .orElseThrow(() -> new NotFoundException(("この商品は見つかりません。")));

        return ResponseDTO.<ProductDTO>builder()
                .status(HttpStatus.OK.value())
                .message(id + "-商品の取得に成功しました。")
                .data(productMapper.toDTO(product))
                .build();
    }

    /**
     * 指定IDの商品情報を更新する。
     * 更新可能項目:
     * - カテゴリ
     * - 名前
     * - 商品コード
     * - 説明
     * - ステータス
     *
     * @param id         更新対象の商品ID
     * @param productDTO 更新情報を持つDTO
     * @return 更新後の商品DTOを含むレスポンス
     * @throws NotFoundException 指定した商品またはカテゴリが存在しない場合
     */
    @Override
    public ResponseDTO<ProductDTO> updateProduct(Long id, ProductDTO productDTO) {

        Product existingProduct = productRepository.findById(id)
                .orElseThrow(() -> new NotFoundException(("この商品は見つかりません。")));

        if (productDTO.getCategoryName() != null && !productDTO.getCategoryName().isBlank()) {
            existingProduct.setCategory(
                    categoryRepository.findByName(productDTO.getCategoryName())
                            .orElseThrow(() -> new NotFoundException(productDTO.getCategoryName() + "カテゴリは見つかりません。")));
        }
        if (productDTO.getName() != null && !productDTO.getName().isBlank()) {
            existingProduct.setName(productDTO.getName());
        }
        if (productDTO.getProductCode() != null && !productDTO.getProductCode().isBlank()) {
            existingProduct.setProductCode(productDTO.getProductCode());
        }
        if (productDTO.getDescription() != null && !productDTO.getDescription().isBlank()) {
            existingProduct.setDescription(productDTO.getDescription());
        }
        if (productDTO.getStatus() != null) {
            existingProduct.setStatus(productDTO.getStatus());
        }
        Product updatedProduct = productRepository.save(existingProduct);
        return ResponseDTO.<ProductDTO>builder()
                .status(HttpStatus.OK.value())
                .message("更新に成功しました。")
                .data(productMapper.toDTO(updatedProduct))
                .build();
    }

    /**
     * 指定IDの商品を削除する。
     *
     * @param id 削除対象の商品ID
     * @return 成功メッセージを含むレスポンス
     * @throws NotFoundException 指定した商品が存在しない場合
     */
    @Override
    public ResponseDTO<Void> deleteProduct(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("この商品は存在していません。"));
        productRepository.delete(product);
        return ResponseDTO.<Void>builder()
                .status(HttpStatus.OK.value())
                .message("削除に成功しました。")
                .build();
    }

    /**
     * 指定カテゴリに属する商品一覧を取得する。
     *
     * @param categoryId 取得対象のカテゴリID
     * @return 指定カテゴリに属する商品DTOのリストを含むレスポンス
     * @throws NotFoundException 指定したカテゴリが存在しない場合
     */
    @Override
    public ResponseDTO<List<ProductDTO>> getProductsByCategory(Long categoryId) {
        boolean existingCategory = categoryRepository.existsById(categoryId);
        if (!existingCategory) {
            throw new NotFoundException("このカテゴリは存在していません。");
        }
        List<Product> products = productRepository.findByCategoryId(categoryId);
        List<ProductDTO> productDTOs = productMapper.toDTOList(products);
        return ResponseDTO.<List<ProductDTO>>builder()
                .status(HttpStatus.OK.value())
                .message("取得に成功しました。")
                .data(productDTOs)
                .build();
    }

    /**
     * キーワードで商品を検索する。
     *
     * @param keyword 検索するキーワード
     * @return 検索結果の商品DTOのリストを含むレスポンス
     * @throws ResponseStatusException キーワードが空の場合（BAD_REQUEST）
     */
    @Override
    public ResponseDTO<List<ProductDTO>> searchProducts(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "検索キーワードを入力してください。");
        }
        List<Product> products = productRepository.searchProducts(keyword);
        List<ProductDTO> productDTOs = productMapper.toDTOList(products);
        if (productDTOs.isEmpty()) {
            return ResponseDTO.<List<ProductDTO>>builder()
                    .status(HttpStatus.OK.value())
                    .message("該当する商品がありません。")
                    .data(productDTOs)
                    .build();
        }
        return ResponseDTO.<List<ProductDTO>>builder()
                .status(HttpStatus.OK.value())
                .message("取得に成功しました。")
                .data(productDTOs)
                .build();
    }

}
